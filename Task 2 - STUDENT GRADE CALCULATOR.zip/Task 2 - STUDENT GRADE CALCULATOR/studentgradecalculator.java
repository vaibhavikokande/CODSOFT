import java.util.Scanner;

public class studentgradecalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int total_marks = 0;

        System.out.print("Enter the number of subjects: ");
        int total__Subjects = scanner.nextInt();

        
        for (int i = 1; i <= total__Subjects; i++) {
            System.out.print("Enter marks obtained in subject " + i + " (out of 100): ");
            int marks = scanner.nextInt();
            total_marks += marks;
        }

        
        double average_percentage = (double) total_marks / total__Subjects;

        // Grade calculation based on average percentage
        char grade;
        if (average_percentage >= 90) {
            grade = 'A';
        } else if (average_percentage >= 80) {
            grade = 'B';
        } else if (average_percentage >= 70) {
            grade = 'C';
        } else if (average_percentage >= 60) {
            grade = 'D';
        } else {
            grade = 'F';
        }

        // Displaying results
        System.out.println("Total Marks: " + total_marks);
        System.out.println("Average Percentage: " + average_percentage);
        System.out.println("Grade: " + grade);
        
        
        scanner.close();
    }
}
